/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package variable_tipedata;

/**
 *
 * @author HP
 */
public class Variable_TipeData {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int var1 = 56; 
        double var2 = 0.543; 
        boolean var3 = true; 
        char var4 = 'A'; 
        String var5 = "Belajar Java"; 
        System.out.println(var1); 
        System.out.println(var2); 
        System.out.println(var3); 
        System.out.println(var4); 
        System.out.println(var5);
    }
    
}
